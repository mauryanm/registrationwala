<?php

return [
    'by_pageview'            => 'După pagini',
    'by_sessions'            => 'După sesiuni',
    'by_users'               => 'După utilizatori',
    'no_client_id'           => 'Pentru a vedea statisticile din analytics aveți nevoie de google analytics cliend id pe care să-l adăugați în setări pentru cheia <code>google_analytics_client_id</code>. Puteți obține cheia(analytics cliend id) în contul dvs. Google developers console:',
    'set_view'               => 'Alegeți modul de vizualizare',
    'this_vs_last_week'      => 'Săptămâna aceasta în comparație cu săptămâna trecută.',
    'this_vs_last_year'      => 'Anul acesta în comparație cu anul trecut',
    'top_browsers'           => 'Top browser-e',
    'top_countries'          => 'Top țări',
    'various_visualizations' => 'Vizualizări diverse',
];
