<?php

return [
    'by_pageview'            => 'По преглед на страница',
    'by_sessions'            => 'По сесии',
    'by_users'               => 'По потребители',
    'no_client_id'           => 'За да видите анализи ще трябва да вземете вашият google analytics client id и го добавите към настройките на сайта ви за <code>google_analytics_client_id</code>. За да вземете вашия ключ, отидете в Google developer console:',
    'set_view'               => 'Изберете преглед',
    'this_vs_last_week'      => 'Тази седмица срещу последната седмица',
    'this_vs_last_year'      => 'Тази година срещу последната година',
    'top_browsers'           => 'Топ Browsers',
    'top_countries'          => 'Топ Държави',
    'various_visualizations' => 'Различни визуализации',
];
