<?php

return [
    'symlink_created_text'   => 'Създадохме липсвашия symlink за вас',
    'symlink_created_title'  => 'Липсващ storage symlink създаден',
    'symlink_failed_text'    => 'Не успяхме да генерираме липсващия symlink за вашата апликация. Изглежда вашия хостинг не го поддържа.',
    'symlink_failed_title'   => 'Не можахме да създадем липсващия storage symlink',
    'symlink_missing_button' => 'Поправи го',
    'symlink_missing_text'   => 'Не можахме да намерим storage symlink. Това може да доведе до проблеми със зареждането на медиа файлове в браузъра.',
    'symlink_missing_title'  => 'Липсващ storage symlink',
];
