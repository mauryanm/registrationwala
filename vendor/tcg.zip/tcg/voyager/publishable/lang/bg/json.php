<?php

return [
    'invalid'           => 'Неправилен JSON',
    'invalid_message'   => 'Изглежда представихте неправилен JSON.',
    'valid'             => 'Валиден JSON',
    'validation_errors' => 'Проблеми с валидацията',
];
