<?php

return [
    'last_week' => 'Миналата седмица',
    'last_year' => 'Миналата година',
    'this_week' => 'Тази седмица',
    'this_year' => 'Тази седмица',
];
