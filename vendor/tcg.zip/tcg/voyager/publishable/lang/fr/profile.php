<?php

return [
    'avatar'          => 'Avatar',
    'edit'            => 'Editer mon profil',
    'edit_user'       => 'Editer l\'utilisateur',
    'password'        => 'Mot de passe',
    'password_hint'   => 'Laissez vide pour garder le même',
    'role'            => 'Rôle',
    'roles'           => 'Rôles',
    'role_default'    => 'Rôle par défaut',
    'roles_additional'=> 'Rôles additionnels',
    'user_role'       => 'Rôle utilisateur',
];
