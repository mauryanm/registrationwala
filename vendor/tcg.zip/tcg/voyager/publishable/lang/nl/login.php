<?php

return [
    'loggingin'    => 'Aan het inloggen',
    'signin_below' => 'Log hier onder in:',
    'welcome'      => 'Welkom bij Voyager. De missende admin voor Laravel',
];
