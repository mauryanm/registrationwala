<?php

return [
    'footer_copyright'  => 'Gemaakt met <i class="voyager-heart"></i> door',
    'footer_copyright2' => 'Gemaakt met rum en nog meer rum',
];
