<?php

return [
    'field_password_keep'          => 'Deixar vazio para manter o atual',
    'field_select_dd_relationship' => 'Certifique-se de configurar o relacionamento apropriado no método :method da classe :class.',
    'type_checkbox'                => 'Check Box', //todo find suitable translation
    'type_codeeditor'              => 'Editor de Código',
    'type_file'                    => 'Arquivo',
    'type_image'                   => 'Imagem',
    'type_radiobutton'             => 'Radio Button', //todo find suitable translation
    'type_richtextbox'             => 'Rich Textbox', //todo find suitable translation
    'type_selectdropdown'          => 'Selecione Dropdown', //todo find suitable translation
    'type_textarea'                => 'Text Area', //todo find suitable translation
    'type_textbox'                 => 'Text Box', //todo find suitable translation
];
