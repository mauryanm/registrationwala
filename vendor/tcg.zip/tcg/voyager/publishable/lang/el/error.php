<?php

return [
    'symlink_created_text'   => 'Μόλις δημιουργήσαμε το symlink που έλειπε για εσάς.',
    'symlink_created_title'  => 'Το storage symlink που έλειπε δημιουργήθηκε',
    'symlink_failed_text'    => 'Δεν καταφέραμε να δημιουργήσουμε το symlink που έλειπε για την εφαρμογή σας. Φαίνεται ότι ο πάροχος φιλοξενία του site σας δεν το υποστηρίζει.',
    'symlink_failed_title'   => 'Δεν καταφέραμε να δημιουργήσουμε το storage symlink που έλειπε',
    'symlink_missing_button' => 'Επιδιόρθωση',
    'symlink_missing_text'   => 'Δεν μπορέσαμε να βρούμε το storage symlink. Αυτό μπορεί να προκαλέσει προβλήματα με τη φόρτωση αρχείων από τον browser.',
    'symlink_missing_title'  => 'Λείπει το storage symlink',
];
