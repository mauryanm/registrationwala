<?php

return [
    'invalid'           => 'Μη έγκυρο JSON',
    'invalid_message'   => 'Φαίνεται ότι εισάγατε μη έγκυρο JSON.',
    'valid'             => 'Έγκυρο JSON',
    'validation_errors' => 'Λάθη επικύρωσης',
];
