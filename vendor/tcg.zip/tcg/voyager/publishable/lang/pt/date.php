<?php

return [
    'last_week' => 'Semana Passada',
    'last_year' => 'Ano Passado',
    'this_week' => 'Esta Semana',
    'this_year' => 'Este Ano',
];
