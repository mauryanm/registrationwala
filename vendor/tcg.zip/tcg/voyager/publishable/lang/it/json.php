<?php

return [
    'invalid'           => 'Json non valido',
    'invalid_message'   => 'Sembra che tu abbia introdotto qualche JSON non valido.',
    'valid'             => 'Json valido',
    'validation_errors' => 'Errori di validazione',
];
